import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './styles/Home.css';
import LoaderOverlay from './LoaderOverlay';

function Home() {
  const [showModal, setShowModal] = useState(false);
  const [showClaimModal, setShowClaimModal] = useState(false);
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [imei, setImei] = useState('');
  const [comments, setComments] = useState('');
  const [insurances, setInsurances] = useState([]);
  const [selectedInsuranceIndex, setSelectedInsuranceIndex] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const fetchInsurances = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://10.2.1.148:5001/api/insurances', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      setInsurances(response.data);
      setLoading(false);
    } catch (error) {
      setLoading(false);
      console.error('Error fetching insurances:', error);
    }
  };

  useEffect(() => {
    fetchInsurances();
  }, []);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const newInsurance = { name, address, imei };
      await axios.post('http://10.2.1.148:5001/api/insurances', newInsurance, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      fetchInsurances();
      setShowModal(false);
      setName('');
      setAddress('');
      setImei('');
      setLoading(false);
    } catch (error) {
      setLoading(false);
      console.error('Error submitting insurance:', error);
    }
  };

  const handleClaimSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const insurance = insurances[selectedInsuranceIndex];
      const response = await axios.post('http://10.2.1.148:5001/api/applyClaim', { imei: insurance.imei, comments }, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      if (response.data) {
        fetchInsurances();
        setShowClaimModal(false);
        setComments('');
        setSelectedInsuranceIndex(null);
        setLoading(false);
      }
    } catch (error) {
      setLoading(false);
      console.error('Error submitting claim:', error);
    }
  };

  const handleClaim = (index) => {
    setSelectedInsuranceIndex(index);
    setShowClaimModal(true);
  };


  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <div className="home-container">
      <LoaderOverlay loading={loading} />
      <header className="header">
        <div className="logo">Insurance Company 1</div>
        <button className="logout-button" onClick={handleLogout}>Logout</button>
      </header>
      <main>
        {insurances.map((insurance, index) => (
          <div className="card" key={index}>
            <p><strong>Name:</strong> {insurance.name}</p>
            <p><strong>Address:</strong> {insurance.address}</p>
            <p><strong>IMEI:</strong> {insurance.imei}</p>
            {insurance.status && <p><strong>Status:</strong> {insurance.status}</p>}
            {insurance.comments && <p><strong>Comments:</strong> {insurance.comments}</p>}
            {insurance.status === null && (
              <button className="claim-button" onClick={() => handleClaim(index)}>Claim</button>
            )}
            <button className="refresh-button" onClick={() => fetchInsurances()}>Refresh</button>
          </div>
        ))}
        <button className="buy-insurance-button" onClick={() => setShowModal(true)}>$ Buy Insurance</button>
      </main>
      {showModal && (
        <div className="modal">
          <div className="modal-content">
            <h2>Buy Insurance</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Name:</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              <div className="form-group">
                <label>Address:</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  required
                />
              </div>
              <div className="form-group">
                <label>IMEI Number:</label>
                <input
                  type="text"
                  value={imei}
                  onChange={(e) => setImei(e.target.value)}
                  required
                />
              </div>
              <button type="submit">Submit</button>
              <button type="button" onClick={() => setShowModal(false)}>Cancel</button>
            </form>
          </div>
        </div>
      )}
      {showClaimModal && (
        <div className="modal">
          <div className="modal-content">
            <h2>Submit Claim</h2>
            <form onSubmit={handleClaimSubmit}>
              <div className="form-group">
                <label>Comments:</label>
                <textarea
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  required
                />
              </div>
              <button type="submit">Submit</button>
              <button type="button" onClick={() => setShowClaimModal(false)}>Cancel</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Home;
