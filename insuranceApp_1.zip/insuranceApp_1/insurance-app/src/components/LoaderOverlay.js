import React from 'react';
import { ClipLoader } from 'react-spinners';
import './styles/LoaderOverlay.css';

function LoaderOverlay({ loading }) {
    if (!loading) return null;

    return (
        <div className="loader-overlay">
            <ClipLoader size={50} />
        </div>
    );
}

export default LoaderOverlay;
