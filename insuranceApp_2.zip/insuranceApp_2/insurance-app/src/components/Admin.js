import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './styles/Admin.css';
import LoaderOverlay from './LoaderOverlay';

function Admin() {
    const [insurances, setInsurances] = useState([]);
    const [selectedInsurance, setSelectedInsurance] = useState(null);
    const [status, setStatus] = useState('');
    const [comments, setComments] = useState('');
    const [claimedStatus, setClaimedStatus] = useState(null);
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    const fetchInsurances = async () => {
        setLoading(true);
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get('http://10.2.1.148:5002/api/insurances', {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            setInsurances(response.data);
            setLoading(false);
        } catch (error) {
            setLoading(false);
            console.error('Error fetching insurances:', error);
        }
    };

    useEffect(() => {
        fetchInsurances();
    }, []);

    const handleUpdateStatus = async (event) => {
        event.preventDefault();
        setLoading(true);
        try {
            const token = localStorage.getItem('token');
            const response = await axios.post('http://10.2.1.148:5002/api/updateStatus', { imei: selectedInsurance.imei, status, comments }, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            if (response.data) {
                fetchInsurances();
                setSelectedInsurance(null);
                setStatus('');
                setComments('');
                setClaimedStatus(null);
                setLoading(false);
            }
        } catch (error) {
            setLoading(false);
            console.error('Error updating status:', error);
        }
    };

    const handleCheckClaimedStatus = async (insurance) => {
        setLoading(true);
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get(`http://10.2.1.148:5002/isClaimed/${insurance.imei}`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            setClaimedStatus(response.data.claimed);
            setSelectedInsurance(insurance);
            setLoading(false);
        } catch (error) {
            setLoading(false);
            console.error('Error checking claimed status:', error);
        }
    };

    const handleLogout = () => {
        localStorage.removeItem('token');
        navigate('/login');
    };

    return (
        <div className="admin-container">
            <LoaderOverlay loading={loading} />
            <header className="header">
                <div className="logo">Insurance Admin Panel 2</div>
                <button className="logout-button" onClick={handleLogout}>Logout</button>
            </header>
            <main>
                <h2>Insurance Claims</h2>
                {insurances.map((insurance, index) => {
                    if (insurance.status) {
                        return (<div className="card" key={index}>
                            <p><strong>Name:</strong> {insurance.name}</p>
                            <p><strong>Address:</strong> {insurance.address}</p>
                            <p><strong>IMEI:</strong> {insurance.imei}</p>
                            {insurance.status && <p><strong>Status:</strong> {insurance.status}</p>}
                            {insurance.comments && <p><strong>Comments:</strong> {insurance.comments}</p>}
                            {insurance.status === 'pending' && (
                                <button className="update-button" onClick={() => handleCheckClaimedStatus(insurance)}>Update Status</button>
                            )}
                        </div>);
                    }

                })}
                {selectedInsurance && (
                    <div className="modal">
                        <div className="modal-content">
                            <h2>Update Status</h2>
                            {claimedStatus ? <div class="alert-danger">
                                <strong>Claimed Status : </strong>Already Claimed...!
                            </div> : <div class="alert-success">
                                <strong>Claimed Status :</strong> Not Claimed yet...!
                            </div>}
                            <form onSubmit={handleUpdateStatus}>
                                <div className="form-group">
                                    <label>Status:</label>
                                    <select value={status} onChange={(e) => setStatus(e.target.value)} required>
                                        <option value="">Select Status</option>
                                        <option value="accepted">Accepted</option>
                                        <option value="rejected">Rejected</option>
                                    </select>
                                </div>
                                <div className="form-group">
                                    <label>Comments:</label>
                                    <textarea value={comments} onChange={(e) => setComments(e.target.value)} required />
                                </div>
                                <button type="submit">Submit</button>
                                <button type="button" onClick={() => setSelectedInsurance(null)}>Cancel</button>
                            </form>
                        </div>
                    </div>
                )}
            </main>
        </div>
    );
}

export default Admin;
